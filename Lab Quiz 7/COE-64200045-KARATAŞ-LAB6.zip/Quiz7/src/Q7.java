/*

NAME: BURAK
SURNAME: KARATAŞ
GRADE: COE 2nd Grade
ID: 64200045

 */


public class Q7 {

    public abstract static class Marks {
    }

    //class A extends abstract class Marks
    public static class A extends Marks {
        int marks1,marks2;
        //The constructor of student A
        public A(int marks1, int marks2)
        {
            this.marks1=marks1;
            this.marks2=marks2;
        }
        private double getPercentage() {
            //calculate percentage
            return ((double)(this.marks1+ this.marks2)*100)/(double)200;//return percentage
        }
    }

    //class B extends abstract class Marks
    public static class B extends Marks {
        int marks1,marks2,marks3;
        //The constructor of student B
        public B(int marks1, int marks2, int marks3)
        {
            this.marks1=marks1;
            this.marks2=marks2;
            this.marks3=marks3;
        }
        private double getPercentage() {
            //calculate percentage
            return ((double)(this.marks1+ this.marks2+ this.marks3)*100)/(double)300;//return percentage
        }
    }

    //class B extends abstract class Marks
    public static class C extends Marks {
        int marks1,marks2,marks3;
        //The constructor of student C
        public C(int marks1,int marks2,int marks3)
        {
            this.marks1=marks1;
            this.marks2=marks2;
            this.marks3=marks3;
        }
        private double getPercentage() {
            //calculate percentage
            return ((double)(this.marks1+ this.marks2+ this.marks3)*100)/(double)300;//return percentage
        }
    }


    public static class ABTest {

        public static void main(String[] args) {
            //Object of class A
            A a=new A(90,60);
            //object of class B
            B b=new B(65,70,75);
            //object of class C
            C c=new C(80,90,100);
            //call method and print percentage for student A
            System.out.println("Student A is taking 2 subjects: his percentage = "+a.getPercentage()+ "%");
            //call method and print percentage for student B
            System.out.println("Student B is taking 3 subjects: his percentage = "+b.getPercentage()+ "%");
            //call method and print percentage for student C
            System.out.println("Student C is taking 3 subjects: his percentage = "+c.getPercentage()+ "%");
        }

    }

}
