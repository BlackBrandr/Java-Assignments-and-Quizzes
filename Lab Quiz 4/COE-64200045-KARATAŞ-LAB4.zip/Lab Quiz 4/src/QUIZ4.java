import java.util.Scanner;

public class QUIZ4 {

    public static void main(String[] args)
    {
        // I defined array
        int[][] My_Array = new int[3][3];
        // Define a scanner
        Scanner s1 = new Scanner(System.in);
        System.out.println("Enter elements one by one, starting by first row elements.");
        // Take inputs one by one
        for(int i = 0 ; i < 3 ; i++){
            for(int j = 0 ; j < 3; j++)
            {
                System.out.println("Please enter the element");
                My_Array[i][j] = s1.nextInt();
            }
            System.out.println();
        }
        // Print 2D ARRAY
        System.out.println("\n" + "Your 2D array is: " + "\n");
        for(int i = 0 ; i < 3 ; i++){
            for(int j = 0 ; j < 3; j++)
            {
                System.out.print(My_Array[i][j] + " " );
            }
            System.out.println();
        }

        //Find max element in array
        //Find max elements location in array

        int max = 0;
        int maxRow = 0;
        int maxColumn = 0;
        for(int i = 0 ; i < 3 ; i++)
            for(int j = 0 ; j < 3; j++) {
                if (My_Array[i][j] > max) {
                    maxRow = i;
                    maxColumn = j;
                    max = My_Array[i][j];
                }

                //Print max number and location
            }
        System.out.println("\n" + "the maximum number in the array is: " + max);
        System.out.println("\n" + "index of the maximum number is: [" + maxRow + "] [" + maxColumn + "]");
    }
}
