package q1;// Student Name: Burak Karataş
// OOP Lab Quiz 5

import java.util.*;

public class Student {

    // CONSTRUCTORS
    int id;
    String name;
    String school_name;
    String class_name;
    int[] grades = new int[4];

    // FUNCTION FOR GETTING AVERAGE
    static int GET_AVERAGE(int[] grades) {
        int SUM = 0;
        int AVERAGE;
        for(int i = 0; i < 4; i++) {
            SUM += grades[i];
        }
        AVERAGE = SUM / 4;
        return AVERAGE;
    }

    public static void main(String[] args) {

        // SCANNERS
        Scanner sc1= new Scanner(System.in);
        Scanner sc2= new Scanner(System.in);

        //OBJECTS
        Student STUDENT1 = new Student();
        Student STUDENT2 = new Student();

        // TAKING INPUTS FROM USER
        System.out.println("Enter id for first student: ");
        STUDENT1.id = Integer.parseInt(sc1.nextLine());

        System.out.println("Enter name for first student: ");
        STUDENT1.name = sc1.nextLine();

        System.out.println("Enter school name for first student: ");
        STUDENT1.school_name = sc1.nextLine();

        System.out.println("Enter class name for first student: ");
        STUDENT1.class_name = sc1.nextLine();

        System.out.println("Enter four grades: ");

        for (int i = 0; i < 4; i++) {
            STUDENT1.grades[i] = sc1.nextInt();
        }

        // OUTPUT 1
        System.out.println("ID: " + STUDENT1.id + " Name: " + STUDENT1.name + " Class Name: " + STUDENT1.class_name +
                " School Name: " + STUDENT1.school_name + " Grades: " + Arrays.toString(STUDENT1.grades) + " Average of Grades: " + GET_AVERAGE(STUDENT1.grades) + "\n");

        System.out.println("Enter id for second student: ");
        STUDENT2.id = Integer.parseInt(sc2.nextLine());

        System.out.println("Enter name for second student: ");
        STUDENT2.name = sc2.nextLine();

        System.out.println("Enter school name for second student: ");
        STUDENT2.school_name = sc2.nextLine();

        System.out.println("Enter class name for second student: ");
        STUDENT2.class_name = sc2.nextLine();

        System.out.println("Enter four grades: ");

        for (int i = 0; i < 4; i++) {
            STUDENT2.grades[i] = sc2.nextInt();
        }

        // OUTPUT 2
        System.out.println("ID: " + STUDENT2.id + " Name: " + STUDENT2.name + " Class Name: " + STUDENT2.class_name +
                " School Name: " + STUDENT2.school_name + " Grades: " + Arrays.toString(STUDENT2.grades) + " Average of Grades: " + GET_AVERAGE(STUDENT2.grades));

    }

}
