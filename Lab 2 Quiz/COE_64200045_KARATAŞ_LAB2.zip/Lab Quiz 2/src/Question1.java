import java.util.*;

public class Question1 {

    public static void main(String[] args) {

        Scanner sc= new Scanner(System.in);

        // I get the Marital Status from user
        System.out.print("please enter marital status (single=1 / married =2):");
        int status = sc.nextInt();

        // I get the Annual Income from user
        System.out.print("please enter your annual income:");
        int income = sc.nextInt();

        // There are tax calculations
        double Tax1 = (0.10 * income);
        double Tax2 = (0.15 * income);
        double Tax3 = (0.20 * income);

        // Output of tax payments for each case
        if (status == 1 && 0 < income && income < 10000) {

            System.out.print("the tax you need to pay:  " + Tax1);
        }

        else if (status == 1 && 10000 < income && income < 20000) {

            System.out.print("the tax you need to pay:  " + Tax2);
        }

        else if (status == 1 && 20000 < income && income < 50000) {

            System.out.print("the tax you need to pay:  " + Tax3);
        }

        else if (status == 2 && 0 < income && income < 20000) {

            System.out.print("the tax you need to pay:  " + Tax1);
        }

        else if (status == 2 && 20000 < income && income < 30000) {

            System.out.print("the tax you need to pay:  " + Tax2);
        }

        else if (status == 2 && 30000 < income && income < 70000) {

            System.out.print("the tax you need to pay:  " + Tax3 );
        }

        else {

            System.out.print("Please  recalculate your tax payments");
        }


    }


}
